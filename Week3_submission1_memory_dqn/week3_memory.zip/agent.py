from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn
from collections import deque

ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

STACK = 4
OBS_DIM = 18 * STACK


class DQN(nn.Module):
    def __init__(self, in_dim: int = OBS_DIM, n_actions: int = 5):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, n_actions),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


_model: Optional[DQN] = None
_frame_buffer: Optional[deque] = None

_last_action: Optional[int] = None
_repeat_count: int = 0

_MAX_REPEAT = 2
_CLOSE_Q_DELTA = 0.05


def _load_once():
    global _model
    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError(f"weights.pth not found at {wpath}")
    
    print("Reached here 1")
    m = DQN()

    sd = torch.load(wpath, map_location="cpu")
        

    # if isinstance(sd, dict):
    #     if "state_dict" in sd:
    #         sd = sd["state_dict"]
    #     m.load_state_dict(sd)
    # else:
    #     m = sd
    m.load_state_dict(sd)

    m.eval()
    _model = m


def _stack_obs():
    return np.concatenate(list(_frame_buffer), axis=0)


@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _frame_buffer, _last_action, _repeat_count
    print("Reached here 2")
    _load_once()

    if (
        _frame_buffer is None
        or len(_frame_buffer) == 0
        or np.all(obs == 0)
    ):
        _frame_buffer = deque(maxlen=STACK)
        for _ in range(STACK):
            _frame_buffer.append(obs)
        _last_action = None
        _repeat_count = 0
    else:
        _frame_buffer.append(obs)

    S = _stack_obs()

    x = torch.tensor(S, dtype=torch.float32).unsqueeze(0)
    q = _model(x).squeeze(0).cpu().numpy()

    best = int(np.argmax(q))

    # ---- smoothing ----
    if _last_action is not None:
        order = np.argsort(-q)
        best_q = float(q[order[0]])
        second_q = float(q[order[1]])

        if (best_q - second_q) < _CLOSE_Q_DELTA:
            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]